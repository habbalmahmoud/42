/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_path.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/21 13:28:33 by mhabbal           #+#    #+#             */
/*   Updated: 2024/07/21 15:32:49 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inlcudes/pipex.h"

void	free_2d_arrays(char **str, char **str2)
{
	int	i;

	i = 0;
	if (str)
	{
		while (str[i])
		{
			free(str[i]);
			i++;
		}
		free(str);
	}
	i = 0;
	if (str2)
	{
		while (str2[i])
		{
			free(str2[i]);
			i++;
		}
		free(str2);
	}
}

char	*get_path(char	*str, char **env, char *cmd)
{
	char	**list_paths;
	char	**command;
	int		i;

	i = -1;
	while (env[++i])
		if (ft_strncmp(env[i], "PATH", 4) == 0)
			list_paths = ft_split(env[i], ':');
	i = -1;
	command = ft_split(cmd, ' ');
	cmd = ft_strjoin("/", command[0]);
	while (list_paths[++i])
	{
		str = ft_strjoin(list_paths[i], cmd);
		if (access(str, X_OK | R_OK) == 0)
		{
			free(cmd);
			free_2d_arrays(command, list_paths);
			return (str);
		}
		free(str);
	}
	free_2d_arrays(list_paths, command);
	return (free(cmd), NULL);
}
