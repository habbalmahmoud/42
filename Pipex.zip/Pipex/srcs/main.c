/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/09 13:07:42 by mhabbal           #+#    #+#             */
/*   Updated: 2024/07/21 15:53:20 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inlcudes/pipex.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

char	**get_args(char *str, char *av)
{
	char	**args;
	char	**data;

	args = ft_split(av, ' ');
	data = malloc(3 * sizeof(char *));
	data[0] = str;
	data[1] = args[1];
	data[2] = NULL;
	free_2d_arrays(args, NULL);
	return (data);
}

void	begin_pipe(char *path1, char *path2, char **av, char **env)
{
	char	**argv1;
	char	**argv2;
	int		pid;
	int		pid2;
	int		pipefd[2];
	int		infile;
	int		outfile;

	argv1 = get_args(path1, av[2]);
	argv2 = get_args(path2, av[3]);
	if (pipe(pipefd) == -1)
		exit(ft_printf("Error\n"));
	pid = fork();
	infile = open(av[1], O_RDONLY);
	outfile = open(av[3] , O_RDONLY);
	if (pid == -1)
		exit(ft_printf("Error\n"));
	if (pid == 0)
	{
		dup2(outfile, pipefd[1]);
		dup2(pipefd[1], STDOUT_FILENO);
		close(pipefd[0]);
		close(pipefd[1]);
		execve(path1, argv1, env);
	}
	pid2 = fork();
	if (pid2 == -1)
		exit(ft_printf("Error\n"));
	if (pid2 == 0)
	{
		dup2(infile, pipefd[0]);
		dup2(pipefd[0], STDIN_FILENO);
		close(pipefd[0]);
		close(pipefd[1]);
		execve(path2, argv2, env);
	}
	close(pipefd[0]);
	close(pipefd[1]);
	waitpid(pid, NULL, 0);
	waitpid(pid2, NULL, 0);
}

int	main(int argc, char **argv, char **env)
{
	char	*path1;
	char	*path2;

	if (argc != 5)
		exit(ft_printf("Error\n"));
	if (access(argv[1], F_OK))
		exit(ft_printf("Error\n") < 0);
	path1 = get_path(NULL, env, argv[2]);
	path2 = get_path(NULL, env, argv[3]);
	if (!path1 || !path2)
	{
		free(path2);
		free(path1);
		exit(ft_printf("Cmd Error\n"));
	}
	begin_pipe(path1, path2, argv, env);
	free(path1);
	free(path2);
}
